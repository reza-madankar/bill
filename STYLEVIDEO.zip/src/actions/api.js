import axios from "axios";

/* eslint import/no-anonymous-default-export: [2, {"allowObject": true}] */
export default {
    meetDr() {
        return {
            getMeetInfo: (data,isDr) => axios.get(`http://localhost:59639/api/appointment/${data}/${isDr}`)
        }
    }
}