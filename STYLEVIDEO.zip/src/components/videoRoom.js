import React, { useState, useEffect } from 'react';
import { connect } from "react-redux";
import * as actions from "../actions/meetActons";
import Video from 'twilio-video';
import { CameraVideo, Mic, MicMute, CameraVideoOff, Telephone } from 'react-bootstrap-icons';
import { Link, useParams, useLocation } from "react-router-dom";
import Webcam from "react-webcam";

const VideoRoom = (props) => {

    const { token } = useParams();
    const date = new Date();
    const [config, setConfig] = useState({
        roomNameErr: false,
        previewTracks: null,
        localMediaAvailable: true,
        hasJoinedRoom: false,
        activeRoom: ''
    });

    const webcam = true;
    const [mic, setMuteMic] = useState(false);
    const [camera, setMutecamera] = useState(false);
    const [guestCamera, setGuestCamera] = useState(false);
    const [currentRoom, setRoom] = useState();
    const [timer, setTimer] = useState(new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12, 0, 0));
    var query = new URLSearchParams(useLocation().search);

    useEffect(() => {

        setConfig(config);

        setInterval(() => {
            var d = timer;
            setTimer(new Date(d.setSeconds(d.getSeconds() + 1)));

            // if (currentRoom) {
            //     currentRoom.participants.forEach(participant => {

            //         participant.tracks.forEach(publication => {
            //             if (publication.mute === false) {
            //             }
            //             else {
            //             }
            //         });
            //     });
            // }
        }, 1000)

        document.title = props._meetInfo.drName

        if (props._meetInfo.token === '') {

            var isDr = query.get("isDr");

            props.fetchMeetInfo(token, isDr === null ? false : true);
        }


        // eslint-disable-next-line
    }, []);

    useEffect(() => {
        joinRoom();

        // eslint-disable-next-line
    }, [props._meetInfo.token]);

    const joinRoom = () => {
        let connectOptions = {
            name: props._meetInfo.drName
        };

        if (config.previewTracks) {
            connectOptions.tracks = config.previewTracks;
        }

        Video.createLocalTracks({
            audio: true,
            video: true
        }).then(localTracks => {
            return connect(props._meetInfo.token, {
                name: connectOptions.name,
                tracks: localTracks
            });
        }).then(room => {
        });

        Video.connect(props._meetInfo.token, connectOptions).then(room => roomJoined(room), error => {
            console.log('Could not connect to Video Pezeshk: ' + error.message);
        });
    }

    const roomJoined = (room) => {

        room.participants.forEach(participant => {
            setGuestCamera(!guestCamera)
            participant.tracks.forEach(publication => {
                if (publication.isSubscribed) {
                    const track = publication.track;
                    document.getElementById('remote-media-div').appendChild(track.attach());
                }
            });

            participant.on('trackSubscribed', track => {
                document.getElementById('remote-media-div').appendChild(track.attach());
            });

        });


        room.on('participantConnected', participant => {
            setRoom(room)

            participant.tracks.forEach(publication => {
                if (publication.isSubscribed) {
                    const track = publication.track;
                    document.getElementById('remote-media-div').appendChild(track.attach());
                }
            });

            participant.on('trackSubscribed', track => {
                document.getElementById('remote-media-div').appendChild(track.attach());
            });
        });
    }

    const roomOff = () => {
        try {
            currentRoom.disconnect();
        }
        catch {

        }
    }

    const videoMute = () => {
        try {
            currentRoom.localParticipant.videoTracks.forEach(function (trackId, track) {
                if (camera === true) {
                    trackId.enable();
                }
                else {
                    trackId.disable();
                }
            });
            setMutecamera(!camera)
        }
        catch {

        }
    }

    const micMute = () => {
        try {
            currentRoom.localParticipant.audioTracks.forEach(function (trackId, track) {
                if (mic === true) {
                    trackId.enable();
                }
                else {
                    trackId.disable();
                }
            });
            setMuteMic(!mic)
        }
        catch {

        }
    }

    return (
        <div className="room">
            {
                webcam === true ? <div className="webcam"><Webcam Height={170} forceScreenshotSourceSize={true} /></div> : <></>
            }
            {
                <div className="flex-item">
                    <div id="remote-media-div" className={guestCamera === false ? "guestCamera" : ""} />
                </div>
            }
            <span className="timer">{timer.getMinutes().toString().padStart(2, '0')}:{timer.getSeconds().toString().padStart(2, '0')}</span>
            <div className="navigation">
                <div className="controller">
                    <span className="ctr mic" onClick={() => micMute()} >
                        {
                            mic === false ?
                                <Mic color="white" size={20} />
                                :
                                <MicMute color="white" size={20} />
                        }
                    </span>
                    <Link className="btn btn-primary btn-hangup" to="/meet/endCall" onClick={roomOff}>
                        <Telephone color="white" size={20} />
                    </Link>
                    <span className="ctr video" onClick={() => videoMute()}>
                        {
                            camera === false ?
                                <CameraVideo color="white" size={20} />
                                :
                                <CameraVideoOff color="white" size={20} />
                        }
                    </span>
                </div>
            </div>
        </div>
    )
}

const mapStateToProps = state => ({
    _meetInfo: state.meetDr.info
})

const mapActionToProps = {
    fetchMeetInfo: actions.meetInfo
}

export default connect(mapStateToProps, mapActionToProps)(VideoRoom);