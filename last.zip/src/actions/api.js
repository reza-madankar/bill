import axios from "axios";

const baseUrl = "http://localhost:8020/token"

export default {
    meetDr(url = baseUrl) {
        return {
            meetInfo: () => axios.get(url)
        }
    }
}