import api from "./api";

export const ACTION_TYPES = {
    GET_TOKEN: 'GET_TOKEN'
}

export const meetInfo = () => dispatch => {
    api.meetDr().meetInfo()
        .then(response => {
            dispatch({
                type: ACTION_TYPES.GET_TOKEN,
                payload: response.data
            })
        })
        .catch(err => console.log(err))
}
