import { ACTION_TYPES } from "../actions/meetActons";
const initialState = {
    info: {
            identity: null,
            roomName: 'sss',
            roomNameErr: false,
            previewTracks: null,
            localMediaAvailable: true,
            hasJoinedRoom: false,
            activeRoom: '',
            mic: true,
            camera: false,
            token:''
    }
}

export const meetDr = (state = initialState, action) => {

    switch (action.type) {
        case ACTION_TYPES.GET_TOKEN:
            var _info =  state.info;
            _info.token = action.payload.token;
            return {
                ...state,
                info : _info.token
            }
        default:
            return state
    }
}