import React, { useState, useEffect, useRef } from 'react';
import Video from 'twilio-video';
import { CameraVideo, Mic, MicMute, CameraVideoOff, Telephone } from 'react-bootstrap-icons';
import { Link } from "react-router-dom";

import { connect } from "react-redux";
import * as actions from "../actions/meetActons";

const VideoRoom = (props) => {

    const [timer, setTimer] = useState(new Date());
    const [mic, setMuteMic] = useState(false);
    const [camera, setMutecamera] = useState(false);

    useEffect(() => {
        props.fetchMeetInfo();
        joinRoom();
        console.log(props._meetInfo)
        setInterval(() => {
            var d = timer;
            setTimer(new Date(d.setSeconds(d.getSeconds() + 1)));
        }, 1000)

    }, []);

    const joinRoom = () => {

        // this.setState({
        //     roomName: "sample Room",
        //     audio: true,
        // });

        let connectOptions = {
            name: props._meetInfo.roomName
        };

        if (props._meetInfo.previewTracks) {
            connectOptions.tracks = props._meetInfo.previewTracks;
        }

        console.log(props._meetInfo.token)

        Video.connect("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImN0eSI6InR3aWxpby1mcGE7dj0xIn0.eyJqdGkiOiJTSzIzNjkyYjk0YWYyYzQyYmI0ZDIyMjgwYTljZDVmNDQ5LTE2MTk0MjE1MTYiLCJncmFudHMiOnsiaWRlbnRpdHkiOiJNb2hhbW1hZCBSZXphIiwidmlkZW8iOnsicm9vbSI6ImNvb2wgcm9vbSJ9fSwiaWF0IjoxNjE5NDIxNTE2LCJleHAiOjE2MTk0MjUxMTYsImlzcyI6IlNLMjM2OTJiOTRhZjJjNDJiYjRkMjIyODBhOWNkNWY0NDkiLCJzdWIiOiJBQzUwMWY0NmFjYjY1YTgwZDkyMTU3N2NmOGI2NjdhMjk2In0.t79TVLjcQnZJjdEjx0o_wedSzzwGozSMIF-nIphIKiI", connectOptions).then(room => roomJoined(room), error => {
            alert('Could not connect to Video Pezeshk: ' + error.message);
        });
    }

    const attachTracks = (tracks, container) => {
        tracks.forEach(track => {
            container.appendChild(track.attach());
        });
    }

    const attachParticipantTracks = (participant, container) => {
        var tracks = Array.from(participant.tracks.values());
        attachTracks(tracks, container);
    }

    const roomJoined = (room) => {
       
        console.log(room.localParticipant);


            room.localParticipant.tracks.forEach(track => {
                document.getElementById('remote-media-div').appendChild(track.attach());
            });

            room.localParticipant.on('trackAdded', track => {
                document.getElementById('remote-media-div').appendChild(track.attach());
            });
      
    }



    return (
        <div className="room">
            {

                <div className="flex-item">
                    <div id="remote-media-div" />
                </div>

            }
            <span className="timer">{timer.getMinutes().toString().padStart(2, '0')}:{timer.getSeconds().toString().padStart(2, '0')}</span>
            <div className="navigation">
                <div className="controller">
                    <span className="ctr mic" onClick={() => setMuteMic(!mic)}>
                        {
                            mic === false ?
                                <Mic color="white" size={20} />
                                :
                                <MicMute color="white" size={20} />
                        }
                    </span>
                    <Link class="btn btn-primary btn-hangup" to="/endCall">
                        <Telephone color="white" size={20} />
                    </Link>
                    <span className="ctr video" onClick={() => setMutecamera(!camera)}>
                        {
                            camera === false ?
                                <CameraVideo color="white" size={20} />
                                :
                                <CameraVideoOff color="white" size={20} />
                        }
                    </span>
                </div>
            </div>

        </div>
    )
}


const mapStateToProps = state => ({
    _meetInfo: state.meetDr.info
})

const mapActionToProps = {
    fetchMeetInfo: actions.meetInfo
}

export default connect(mapStateToProps, mapActionToProps)(VideoRoom);





// export default class VideoComponent extends Component {
//     constructor(props) {
//         var date = new Date();

//         super();
//         this.state = {
//             identity: null,
//             roomName: '',
//             roomNameErr: false,
//             previewTracks: null,
//             localMediaAvailable: false,
//             hasJoinedRoom: false,
//             activeRoom: '',
//             mic: true,
//             camera: false,
//             timer: new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0, 0)
//         };

//         this.roomJoined = this.roomJoined.bind(this);


//     }




//     componentDidMount() {
//         axios.get('http://localhost:8020/token').then(results => {
//             this.joinRoom(results.data.token);
//         });


//     }

//     render() {
//         let showLocalTrack = this.state.localMediaAvailable ? (
//             <div className="flex-item">
//                 <div ref="localMedia" />
//             </div>
//         ) : <img src={require('../content/img/dr.jpg').default} alt="pezeshk logo" />;

//         return (

//             <div className="room">
//                 {showLocalTrack}
//                 <span className="timer">{this.state.timer.getMinutes().toString().padStart(2, '0')}:{this.state.timer.getSeconds().toString().padStart(2, '0')}</span>
//                 <div className="navigation">
//                     <div className="controller">
//                         <span className="ctr mic" >
//                             {
//                                 this.state.mic === false ?
//                                     <Mic color="white" size={20} />
//                                     :
//                                     <MicMute color="white" size={20} />
//                             }
//                         </span>
//                         <Link class="btn btn-primary btn-hangup" to="/endCall">
//                             <Telephone color="white" size={20} />
//                         </Link>
//                         <span className="ctr video" >
//                             {
//                                 this.state.camera === false ?
//                                     <CameraVideo color="white" size={20} />
//                                     :
//                                     <CameraVideoOff color="white" size={20} />
//                             }
//                         </span>
//                     </div>
//                 </div>

//             </div>
//         );
//     }
// }


