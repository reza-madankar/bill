import React, { useState } from 'react';
import { Row, Col } from 'react-bootstrap';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.scss";
import { CameraVideo, Mic, MicMute, CameraVideoOff } from 'react-bootstrap-icons';
import { Link } from "react-router-dom";
import Webcam from "react-webcam";


function Join() {
    const [mic, setMuteMic] = useState(false);
    const [camera, setMutecamera] = useState(false);
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1
    };

    return (
        <Row className="join">
            <Col className="col2">
                <Slider {...settings}>
                    <div className="sliderItem">
                        <img src={require('../content/img/online-visit.svg').default} alt="pezeshk logo" />
                        <h3>Title 1</h3>
                        <p>
                            Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry
                </p>
                    </div>
                    <div className="sliderItem">
                        <img src={require('../content/img/online-visit.svg').default} alt="pezeshk logo" />
                        <h3>Title 2</h3>
                        <p>
                            Lorem Ipsum is simply dummy text of the printin and typesetting industry.Lorem Ipsum is simply dummy text of the printin and typesetting industry.Lorem Ipsum is simply dummy text of the printin and typesetting industry
                </p>
                    </div>
                </Slider>
            </Col>

            <Col className="col2 ">
                <div className="beforeShow">
                    {
                        camera === false ? <Webcam audio={true} minScreenshotHeight={100} /> : <></>
                    }

                    <div className="controller">
                        <span onClick={() => setMuteMic(!mic)}>
                            {
                                mic === false ?
                                    <Mic color="white" size={20} />
                                    :
                                    <MicMute color="white" size={20} />
                            }
                        </span>
                        <span onClick={() => setMutecamera(!camera)}>
                            {
                                camera === false ?
                                    <CameraVideo color="white" size={20} />
                                    :
                                    <CameraVideoOff color="white" size={20} />
                            }
                        </span>
                    </div>

                </div>
                <div className="users">
                    <div className="userItem">
                        <span className="title">Patient</span>
                        <img src={require('../content/img/patient.png').default} alt="pezeshk logo" />
                        <span className="name">Saeid Keyvan</span>
                    </div>
                    <div className="userItem">
                        <span className="title">Doctor</span>
                        <img src={require('../content/img/dr.png').default} alt="pezeshk logo" />
                        <span className="name">Dr. Rahim AhmadiSaeid Keyvan</span>
                    </div>
                </div>
                <div className="details">
                    <p>Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. </p>
                    <div className="appointmaintDetails">
                        <span className="appointment">Appointment Time</span>
                        <span className="appointmentTime">06:15 AM Sat.6</span>
                    </div>
                    <Link class="btn btn-primary" to={"/room/test" }>Join</Link>
                </div>
            </Col>
        </Row>
    );
}

export default Join;
