import React, { useState, useEffect } from 'react';
import { connect } from "react-redux";
import * as actions from "../actions/meetActons";
import { Row, Col } from 'react-bootstrap';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.scss";
import { CameraVideo, Mic, MicMute, CameraVideoOff } from 'react-bootstrap-icons';
import { Link, useParams } from "react-router-dom";
import Webcam from "react-webcam";


const Join = (props) => {

    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1
    };
    const [mic, setMuteMic] = useState(props._meetInfo.mic);
    const [video, setMuteVideo] = useState(props._meetInfo.video);

    useEffect(() => {
        // console.log( window.location.protocol + '//' + window.location.host)
        props.fetchMeetInfo('0974ab74-1abb-4742-5fee-08d8bf1637c2|1');
    }, []);

    const cameraMute = () => {
        var info = props._meetInfo;
        info.video = !props._meetInfo.video
        props.updateConfig(info)

        setMuteVideo(props._meetInfo.video)
    }

    const micMute = () => {
        var info = props._meetInfo;
        info.mic = !props._meetInfo.mic
        props.updateConfig(info)

        setMuteMic(props._meetInfo.mic)
    }

    return (
        <Row className="join">
            <Col className="col2">
                <Slider {...settings}>
                    <div className="sliderItem">
                        <img src={require('../content/img/online-visit.svg').default} alt="pezeshk logo" />
                        <h3>Title 1</h3>
                        <p>
                            Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry
                </p>
                    </div>
                    <div className="sliderItem">
                        <img src={require('../content/img/online-visit.svg').default} alt="pezeshk logo" />
                        <h3>Title 2</h3>
                        <p>
                            Lorem Ipsum is simply dummy text of the printin and typesetting industry.Lorem Ipsum is simply dummy text of the printin and typesetting industry.Lorem Ipsum is simply dummy text of the printin and typesetting industry
                </p>
                    </div>
                </Slider>
            </Col>

            <Col className="col2 ">
                <div className="beforeShow">
                    {
                        video === false ? <Webcam audio={true} minScreenshotHeight={100} /> : <></>
                    }
                    <div className="controller">
                        <span onClick={() => micMute()}>
                            {
                                mic === false ?
                                    <Mic color="white" size={20} />
                                    :
                                    <MicMute color="white" size={20} />
                            }
                        </span>
                        <span onClick={() => cameraMute()}>
                            {
                                video === false ?
                                    <CameraVideo color="white" size={20} />
                                    :
                                    <CameraVideoOff color="white" size={20} />
                            }
                        </span>
                    </div>
                </div>
                <div className="users">
                    <div className="userItem">
                        <span className="title">Patient</span>
                        <img src={require('../content/img/patient.png').default} alt="pezeshk logo" />
                        <span className="name">{props._meetInfo.patient}</span>
                    </div>
                    <div className="userItem">
                        <span className="title">Doctor</span>
                        <img src={require('../content/img/dr.png').default} alt="pezeshk logo" />
                        <span className="name">{props._meetInfo.drName}</span>
                    </div>
                </div>
                <div className="details">
                    <p>Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. </p>
                    <div className="appointmaintDetails">
                        <span className="appointment">Appointment Time</span>
                        <span className="appointmentTime">{props._meetInfo.appointmentDate}</span>
                    </div>
                    <Link className="btn btn-primary" to={"/room/test"}>Join</Link>
                </div>
            </Col>
        </Row>
    );
}

const mapStateToProps = state => ({
    _meetInfo: state.meetDr.info
})

const mapActionToProps = {
    fetchMeetInfo: actions.meetInfo,
    updateConfig: actions.changeConfig
}

export default connect(mapStateToProps, mapActionToProps)(Join);
