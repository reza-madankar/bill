import React, { useState, useEffect } from 'react';
import { connect } from "react-redux";
import * as actions from "../actions/meetActons";
import Video from 'twilio-video';
import { CameraVideo, Mic, MicMute, CameraVideoOff, Telephone } from 'react-bootstrap-icons';
import { Link } from "react-router-dom";

const VideoRoom = (props) => {
    const date = new Date();
    const [config, setConfig] = useState({
        roomNameErr: false,
        previewTracks: null,
        localMediaAvailable: true,
        hasJoinedRoom: false,
        activeRoom: ''
    });
    const [mic, setMuteMic] = useState(false);
    const [camera, setMutecamera] = useState(false);
    const [currentRoom, setRoom] = useState();
    const [timer, setTimer] = useState(new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12, 0, 0));

    useEffect(() => {
        setInterval(() => {
            var d = timer;
            setTimer(new Date(d.setSeconds(d.getSeconds() + 1)));
        }, 1000)

        document.title = props._meetInfo.drName

        if (props._meetInfo.token === '')
            props.fetchMeetInfo();
    }, []);

    useEffect(() => {
        joinRoom();
    }, [props._meetInfo.token]);

    const joinRoom = () => {
        let connectOptions = {
            name: props._meetInfo.drName
        };

        if (config.previewTracks) {
            connectOptions.tracks = config.previewTracks;
        }

        Video.connect(props._meetInfo.token, connectOptions).then(room => roomJoined(room), error => {
            alert('Could not connect to Video Pezeshk: ' + error.message);
        });
    }

    const roomJoined = (room) => {
        setRoom(room)
         if (props._meetInfo.mic) {
            room.localParticipant.tracks.forEach(track => {
                document.getElementById('remote-media-div').appendChild(track.attach());
            });
        }

      if (props._meetInfo.video) { 
            room.localParticipant.on('trackAdded', track => {
                document.getElementById('remote-media-div').appendChild(track.attach());
            });
        }
   
    }

    const roomOff = () => {
        currentRoom.disconnect();
    }

    const videoMute = () => {
        // currentRoom.localParticipant.videoTracks.forEach(publication => {
        //     publication.track.disable();
        // });

        setMutecamera(!camera)
    }

    const micMute = () => {
        // currentRoom.localParticipant.audioTracks.forEach(publication => {
        //     publication.track.disable();
        // });

        setMuteMic(!mic)
    }

    return (
        <div className="room">
            {
                <div className="flex-item">
                    <div id="remote-media-div" />
                </div>
            }
            <span className="timer">{timer.getMinutes().toString().padStart(2, '0')}:{timer.getSeconds().toString().padStart(2, '0')}</span>
            <div className="navigation">
                <div className="controller">
                    <span className="ctr mic" onClick={() => micMute()} >
                        {
                            mic === false ?
                                <Mic color="white" size={20} />
                                :
                                <MicMute color="white" size={20} />
                        }
                    </span>
                    <Link className="btn btn-primary btn-hangup" to="/endCall" onClick={roomOff}>
                        <Telephone color="white" size={20} />
                    </Link>
                    <span className="ctr video" onClick={() => videoMute()}>
                        {
                            camera === false ?
                                <CameraVideo color="white" size={20} />
                                :
                                <CameraVideoOff color="white" size={20} />
                        }
                    </span>
                </div>
            </div>
        </div>
    )
}

const mapStateToProps = state => ({
    _meetInfo: state.meetDr.info
})

const mapActionToProps = {
    fetchMeetInfo: actions.meetInfo
}

export default connect(mapStateToProps, mapActionToProps)(VideoRoom);