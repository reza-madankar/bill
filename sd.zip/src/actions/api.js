import axios from "axios";

export default {
    meetDr() {
        return {
            getMeetInfo: data => axios.get(`https://pezeshk.drtest.ca/api/appointment/${data}`)
        }
    }
}