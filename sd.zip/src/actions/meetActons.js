import api from "./api";

export const ACTION_TYPES = {
    GET_TOKEN: 'GET_TOKEN',
    SET_CONFIG: 'SET_CONFIG'
}

export const meetInfo = (data) => dispatch => {
    api.meetDr().getMeetInfo(data)
        .then(response => {
            dispatch({
                type: ACTION_TYPES.GET_TOKEN,
                payload: response.data
            })
        })
        .catch(err => console.log(err))
}

export const changeConfig = config => dispatch => {
    dispatch({
        type: ACTION_TYPES.SET_CONFIG,
        payload: config
    })
}