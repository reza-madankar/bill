import { ACTION_TYPES } from "../actions/meetActons";
const initialState = {
    info: {
        token: '',
        identity: null,
        roomName: '',
        appointmentDate: '',
        patient: '',
        drName: '',
        mic: true,
        video: true
    }
}

export const meetDr = (state = initialState, action) => {

    switch (action.type) {
        case ACTION_TYPES.GET_TOKEN:
            return {
                ...state,
                info: action.payload
            }
        case ACTION_TYPES.SET_CONFIG:
            return {
                ...state,
                info: action.payload
            }
        default:
            return state
    }
}