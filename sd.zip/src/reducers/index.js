import { combineReducers } from "redux";
import { meetDr } from "./meet";

export const reducers = combineReducers({
    meetDr
})