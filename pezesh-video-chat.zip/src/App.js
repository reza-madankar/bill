import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import logo from './content/img/logo-pezeshk.png';
import Join from './components/join';
import VideoRoom from './components/videoRoom';

function App() {

  return (
    <>
      <Row className="navbar">
        <Container>
          <Col>
            <img src={logo} alt="pezeshk logo" className="logo" />
          </Col>
        </Container>
      </Row>
      <Container className="mainContainer">
        <VideoRoom />
      </Container>
    </>
  );
}

export default App;
