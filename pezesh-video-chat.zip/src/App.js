import { Container, Row, Col , Button } from 'react-bootstrap';
import logo from './content/img/logo-pezeshk.png';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.scss";


function App() {

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };


  return (
    <>
      <Row className="navbar">
        <Container>
          <Col>
            <img src={logo} alt="pezeshk logo" className="logo" />
          </Col>
        </Container>
      </Row>
      <Container className="mainContainer">
        <Row>
          <Col className="col2">

            <div className="beforeShow">

              <div className="controller">
                <img src={require('./content/img/mic.png').default} alt="pezeshk logo" />
                <img src={require('./content/img/camera.png').default} alt="pezeshk logo" />
              </div>

            </div>
            <div className="users">
              <div className="userItem">
                <span className="title">Patient</span>
                <img src={require('./content/img/patient.png').default} alt="pezeshk logo" />
                <span className="name">Saeid Keyvan</span>
              </div>
              <div className="userItem">
                <h3>Doctor</h3>
                <img src={require('./content/img/dr.png').default} alt="pezeshk logo" />
                <h2>Dr. Rahim AhmadiSaeid Keyvan</h2>
              </div>
            </div>
            <p>Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. </p>
            <div className="appointmaint">
              <span>Appointment Time</span>
              <span>06:15 AM Sat.6</span>
            </div>
            <Button variant="primary">Primary</Button>{' '}
          </Col>
          <Col className="col2">
            <Slider {...settings}>
              <div className="sliderItem">
                <img src={require('./content/img/online-visit.svg').default} alt="pezeshk logo" />
                <h3>Title 1</h3>
                <p>
                  Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry. Lorem Ipsum is simply dummy text of the printin and typesetting industry
                </p>
              </div>
              <div className="sliderItem">
                <img src={require('./content/img/online-visit.svg').default} alt="pezeshk logo" />
                <h3>Title 2</h3>
                <p>
                  Lorem Ipsum is simply dummy text of the printin and typesetting industry.Lorem Ipsum is simply dummy text of the printin and typesetting industry.Lorem Ipsum is simply dummy text of the printin and typesetting industry
                </p>
              </div>
            </Slider>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default App;
