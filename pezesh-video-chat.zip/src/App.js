import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import logo from './content/img/logo-pezeshk.png';
import Join from './components/join';
import VideoRoom from './components/videoRoom';
import PageNotFound from './components/pageNotFound';
import EndCall from './components/endCall';

import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

function App() {
  return (
    <Router>
      <Row className="navbar">
        <Container>
          <Col>
            <img src={logo} alt="pezeshk logo" className="logo" />
          </Col>
        </Container>
      </Row>
      <Container className="mainContainer">
        <Switch>
          <Route exact path="/">
            <Join />
          </Route>
          <Route path="/room">
            <VideoRoom />
          </Route>
          <Route path="/endCall">
            <EndCall />
          </Route>
          <Route>
            <PageNotFound />
          </Route>
        </Switch>

    </Container>
    </Router>
  );
}

export default App;
