import React, { useState } from 'react';
import { Row} from 'react-bootstrap';
import { Link } from "react-router-dom";


const PageNotFound = () => {

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <Row className="pagenotfound">
      <div className="imgNotFound">
        <img src={require('../content/img/404.jpg').default} alt='pezeshk canada page not found' />
      </div>
      <div className="linkBack">
        <Link class="btn btn-primary" to="/">Back to Home</Link>
      </div>
      {/* <Button variant="primary" onClick={handleShow}>
        Launch demo modal
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>Woohoo, you're reading this text in a modal!</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal> */}


    </Row>
  )
}

export default PageNotFound;