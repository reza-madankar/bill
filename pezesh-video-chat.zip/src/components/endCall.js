import React from 'react';
import { Row } from 'react-bootstrap';
import { Link } from "react-router-dom";

const EndCall = () => {
    return (
        <Row className="endCall">
            <h1>Tanks for calling</h1>
            <img src={require('../content/img/online-visit.svg').default} alt='pezeshk canada page not found' />

          <a href="https://pezeshk.ca/" className="btn btn-link" >go to Pezesh.ca</a>
        </Row>
    )
}

export default EndCall;