import React, { useState } from 'react';
import { CameraVideo, Mic, MicMute, CameraVideoOff, Telephone } from 'react-bootstrap-icons';
import { Link } from "react-router-dom";

const VideoRoom = () => {

    const [mic, setMuteMic] = useState(false);
    const [camera, setMutecamera] = useState(false);

    return (
        <div className="room">
            <span className="timer">3:40</span>
            <img src={require('../content/img/dr.jpg').default} alt="pezeshk logo" />
            {/* <img src={require('../content/img/navigation.svg').default} alt="pezeshk logo" /> */}
            <div className="navigation">
                <div className="controller">
                    <span className="ctr mic" onClick={() => setMuteMic(!mic)}>
                        {
                            mic === false ?
                                <Mic color="white" size={20} />
                                :
                                <MicMute color="white" size={20} />
                        }
                    </span>
                    <Link class="btn btn-primary btn-hangup" to="/endCall">
                        <Telephone color="white" size={20} />
                    </Link>
                    <span className="ctr video" onClick={() => setMutecamera(!camera)}>
                        {
                            camera === false ?
                                <CameraVideo color="white" size={20} />
                                :
                                <CameraVideoOff color="white" size={20} />
                        }
                    </span>
                </div>
            </div>
        </div>
    )
}

export default VideoRoom;
