import React, { useState, useEffect } from 'react';
import { CameraVideo, Mic, MicMute, CameraVideoOff, Telephone } from 'react-bootstrap-icons';
import { Link } from "react-router-dom";
import Video from 'twilio-video';
import axios from 'axios';

const VideoRoom = () => {

    const [mic, setMuteMic] = useState(false);
    const [camera, setMutecamera] = useState(false);
    const [config, setConfig] = useState({
        identity: null,
        roomName: 'VisitDr',
        roomNameErr: false, // Track error for room name TextField
        previewTracks: null,
        localMediaAvailable: false,
        hasJoinedRoom: false,
        activeRoom: '' // Track the current active room
    });

    useEffect(() => {
       
        let token = "";
        axios.get('http://localhost:8020/token').then(results => {
            token = results.data.token;
            config.identity = results.data.identity;

       //     setConfig(config);
        
        });
        console.log(token)
        let connectOptions = {
            name: config.roomName
        };

        Video.connect(token, connectOptions).then(roomJoined, error => {
            alert('Could not connect to Twilio: ' + error.message);
        });

    }, [])

  const  roomJoined = (room) =>{
		// Called when a participant joins a room
		// console.log("Joined as '" + this.state.identity + "'");
		// 	config.activeRoom = room,
		// 	config.localMediaAvailable =  true,
		// 	config.hasJoinedRoom=  true

        //     setConfig(config)

		// // Attach LocalParticipant's Tracks, if not already attached.
		// var previewContainer = this.refs.localMedia;
		// if (!previewContainer.querySelector('video')) {
		// 	this.attachParticipantTracks(room.localParticipant, previewContainer);
		// }
	}

    return (
        <div className="room">
            <span className="timer">3:40</span>
            <img src={require('../content/img/dr.jpg').default} alt="pezeshk logo" />
            {/* <img src={require('../content/img/navigation.svg').default} alt="pezeshk logo" /> */}
            <div className="navigation">
                <div className="controller">
                    <span className="ctr mic" onClick={() => setMuteMic(!mic)}>
                        {
                            mic === false ?
                                <Mic color="white" size={20} />
                                :
                                <MicMute color="white" size={20} />
                        }
                    </span>
                    <Link class="btn btn-primary btn-hangup" to="/endCall">
                        <Telephone color="white" size={20} />
                    </Link>
                    <span className="ctr video" onClick={() => setMutecamera(!camera)}>
                        {
                            camera === false ?
                                <CameraVideo color="white" size={20} />
                                :
                                <CameraVideoOff color="white" size={20} />
                        }
                    </span>
                </div>
            </div>
        </div>
    )
}

export default VideoRoom;
