var express = require("express");
var app = express();
var cors = require('cors')
const csvjson = require('csvjson');


const AccessToken = require('twilio').jwt.AccessToken;
var VideoGrant = AccessToken.VideoGrant;



app.listen(8020, () => {
    app.use(cors())

    app.get("/token", (req, res) => {


        const ACCOUNT_SID = 'AC76ee40dc785390cc037290b8c14f6615';
        const API_KEY_SID = 'SK73c923d3383113653a308959f3b824fe';
        const API_KEY_SECRET = 'Ltcmr3CdCTHhD682kOdhDjozXizxd0fD';

        // Used specifically for creating Chat tokens
        var accessToken = new AccessToken(
            ACCOUNT_SID,
            API_KEY_SID,
            API_KEY_SECRET
        );

        accessToken.identity = 'Mohammad Reza';

        var grant = new VideoGrant();
        grant.room = 'cool room';
        accessToken.addGrant(grant);

        res.json({ token: accessToken.toJwt(), identity: 'dr nikName' });

    });
});
