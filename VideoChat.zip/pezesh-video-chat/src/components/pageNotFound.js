import React from 'react';
import { Row} from 'react-bootstrap';
import { Link } from "react-router-dom";

const PageNotFound = () => {
  return (
    <Row className="pagenotfound">
      <div className="imgNotFound">
        <img src={require('../content/img/404.jpg').default} alt='pezeshk canada page not found' />
      </div>
      <div className="linkBack">
        <Link class="btn btn-primary" to="/">Back to Home</Link>
      </div>
    </Row>
  )
}

export default PageNotFound;