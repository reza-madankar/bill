import React, { Component } from 'react';
import Video from 'twilio-video';
import axios from 'axios';
import { CameraVideo, Mic, MicMute, CameraVideoOff, Telephone } from 'react-bootstrap-icons';
import { Link } from "react-router-dom";


export default class VideoComponent extends Component {
    constructor(props) {
        console.log('constructor')
        super();
        this.state = {
            identity: null,
            roomName: '',
            roomNameErr: false,
            previewTracks: null,
            localMediaAvailable: false,
            hasJoinedRoom: false,
            activeRoom: '',
            mic: true,
            camera: false
        };

        this.handleRoomNameChange = this.handleRoomNameChange.bind(this);
        this.roomJoined = this.roomJoined.bind(this);


    }

    handleRoomNameChange(e) {
        let roomName = e.target.value;
        this.setState({ roomName });
    }

    joinRoom(token) {

        this.setState({
            roomName: "sample Room"
        });

        let connectOptions = {
            name: this.state.roomName
        };

        if (this.state.previewTracks) {
            connectOptions.tracks = this.state.previewTracks;
        }
        console.log('token: ' + token)
        Video.connect(token, connectOptions).then(this.roomJoined, error => {
            alert('Could not connect to Video Pezeshk: ' + error.message);
        });
    }

    attachTracks(tracks, container) {
        tracks.forEach(track => {
            container.appendChild(track.attach());
        });
    }

    attachParticipantTracks(participant, container) {
        var tracks = Array.from(participant.tracks.values());
        this.attachTracks(tracks, container);
    }

    detachTracks(tracks) {
        tracks.forEach(track => {
            track.detach().forEach(detachedElement => {
                detachedElement.remove();
            });
        });
    }

    detachParticipantTracks(participant) {
        var tracks = Array.from(participant.tracks.values());
        this.detachTracks(tracks);
    }

    roomJoined(room) {
        this.setState({
            activeRoom: room,
            localMediaAvailable: true,
            hasJoinedRoom: true
        });

        var previewContainer = this.refs.localMedia;
        if (!previewContainer.querySelector('video')) {
            this.attachParticipantTracks(room.localParticipant, previewContainer);
        }
    }

    componentDidMount() {
        console.log('componentDidMount')
        axios.get('http://localhost:8020/token').then(results => {
            this.joinRoom(results.data.token);
        });
    }

    render() {
        let showLocalTrack = this.state.localMediaAvailable ? (
            <div className="flex-item">
                <div ref="localMedia" />
            </div>
        ) : <img src={require('../content/img/dr.jpg').default} alt="pezeshk logo" />;

        return (
            <div className="room">
                <span className="timer">3:40</span>
                {showLocalTrack}

                <div className="navigation">
                    <div className="controller">
                        <span className="ctr mic" >
                            {
                                this.state.mic === false ?
                                    <Mic color="white" size={20} />
                                    :
                                    <MicMute color="white" size={20} />
                            }
                        </span>
                        <Link class="btn btn-primary btn-hangup" to="/endCall">
                            <Telephone color="white" size={20} />
                        </Link>
                        <span className="ctr video" >
                            {
                                this.state.camera === false ?
                                    <CameraVideo color="white" size={20} />
                                    :
                                    <CameraVideoOff color="white" size={20} />
                            }
                        </span>
                    </div>
                </div>

            </div>
        );
    }
}
